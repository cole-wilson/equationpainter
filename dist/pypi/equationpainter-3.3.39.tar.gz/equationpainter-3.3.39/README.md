# Equation Painter
"A way for teachers to make equation painter worksheets for their students."

Grab the file at the [latest release](https://github.com/cole-wilson/wsm/releases/latest), or install with:
`pip3 install equation_painter`
or build from source
```bash
git clone https://github.com/cole-wilson/wsm
cd wsm
python3 ./setup.py develop
```
or Homebrew:
`brew install cole-wilson/taps/Equation_Painter`