import equationpainter.mainfile

def launch():
	equationpainter.mainfile.main()

def main():
	launch()

if __name__ == "__main__":
	main()